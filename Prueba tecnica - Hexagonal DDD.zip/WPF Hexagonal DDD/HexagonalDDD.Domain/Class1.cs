﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HexagonalDDD.Domain
{
    public class Class1
    {
    }
}
